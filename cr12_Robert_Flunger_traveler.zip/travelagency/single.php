<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package travelagency
 */

get_header();
?>
<div class="row mt-3">
	<div id="primary" class="col-md-8 content-area">
		<main id="main" class="site-main ml-3">

		<?php
		while ( have_posts() ) :
			the_post(); ?>
			<div class="border p-3">
				<h1 class="text-center"><?php the_title();?></h1>
				<p class="blog-post-meta text-muted">Posted on: <?php the_time('F j, Y g:i a'); ?>
				<a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></p>
				<hr style="50%">
				<?php the_content(); 
				the_post_navigation();?>
			</div>
			<?php
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

<div class="col-md-4">
	<?php get_sidebar(); ?>
</div>
</div>
<?php get_footer(); ?>