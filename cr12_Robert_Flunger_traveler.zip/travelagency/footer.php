<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package travelagency
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer text-center text-white">
		<div class="site-info my-3">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'Mt.Everest Travel' ) ); ?>">
			</a>
			<i class="fab fa-facebook-square"></i><span><a href=""> Facebook | </a></span>
			<i class="fab fa-twitter-square"></i><span><a href=""> Twitter | </a></span>
			<i class="fab fa-instagram"></i><span><a href=""> Instagram | </a></span>
			<i class="fab fa-youtube"></i><span><a href=""> YouTube | </a></span>
			<i class="fab fa-tumblr"></i><span><a href=""> Tumblr</a></span>
			<hr style="width:80%">
			<h5>&copy 2019 - Mt. Everest Travel. All Rights Reserved. 
			
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
