<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CodeFoodies
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer bg-dark text-center text-white">
		<div class="site-info my-3">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'Mt.Everest Travel' ) ); ?>">
			</a>
			<i class="fab fa-facebook-square"></i><span> Facebook | </span>
			<i class="fab fa-twitter-square"></i><span> Twitter | </span>
			<i class="fab fa-instagram"></i><span> Instagram | </span>
			<i class="fab fa-youtube"></i><span> YouTube | </span>
			<i class="fab fa-tumblr"></i><span> Tumblr</span>
			<hr style="width:80%">
			<h5>&copy 2019 - Mt. Everest Travel. All Rights Reserved. 
			
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
