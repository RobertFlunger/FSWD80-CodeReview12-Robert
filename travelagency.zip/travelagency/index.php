<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package CodeFoodies
 */

get_header();
?>

<div id="carouselfrontpage" class="carousel slide" data-ride="carousel" style="height:95vh;">
    <div class="carousel-inner h-100">
        <div class="carousel-item active h-100">
          	<img src="<?php echo get_template_directory_uri(); ?>/img/1.jpeg" class="d-block w-100 h-100">
          	<div class="carousel-caption d-none d-md-block">
            	<h1 class="display-2">Find your perfect VACATION</h1>
            	<p class="display-4">Book now!</p>
          	</div>
        </div>
        <div class="carousel-item h-100">
          	<img src="<?php echo get_template_directory_uri(); ?>/img/2.jpeg" class="d-block w-100 h-100">
          	<div class="carousel-caption d-none d-md-block">
            	<h1 class="display-2">SPECIAL SALE</h1>
            	<p class="display-4">-20% OFF on EVERYTHING until 10.12.2019</p>
          	</div>          
        </div>
        <div class="carousel-item h-100">
          	<img src="<?php echo get_template_directory_uri(); ?>/img/3.jpeg" class="d-block w-100 h-100">
          	<div class="carousel-caption d-none d-md-block">
            	<h1 class="display-2">Travel the World</h1>
            	<p class="display-4">We offer trips to destinations EVERYWHERE around the globe</p>
          	</div>          
        </div>
    </div>
</div>

<div class="container mt-5">
	<div class="row">
		<div class="col-md-5">
			<h2>ABOUT US</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo a minus quidem amet quos accusantium modi tempora, doloribus earum nesciunt qui nihil atque, in magni praesentium, odit distinctio fugiat aliquid.</p>
		</div>
		<div class="col-md-5 offset-md-2">
			<h2>OUR MISSION</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo a minus quidem amet quos accusantium modi tempora, doloribus earum nesciunt qui nihil atque, in magni praesentium, odit distinctio fugiat aliquid.</p>
		</div>
	</div>
</div>

	<div id="primary" class="content-area mt-3">
		<main id="main" class="site-main">
		<div class="container-fluid">
			<div class="row d-flex justify-content-around">
		<?php
		if ( have_posts() ) :

			/* Start the Loop */
			while ( have_posts() ) :
				the_post(); ?>
				<div class="card border-0" style="width: 24rem">
					<?php if ( has_post_thumbnail() ) : ?>
                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'single-post-thumbnail' ); ?></a>
                	<?php endif; ?>
					<div class="card-body">
						<h5 class="post-category text-center text-muted" style="color:grey"><?php the_category('-'); ?></h5>
						<a href="<?php the_permalink(); ?>"><h4 class="card-title text-center"><?php the_title(); ?></h4></a>
						<hr style="width:35%">
						<p><?php the_excerpt(); ?></p>
						<p class="text-muted"><?php echo the_time('F jS, Y');?></p>
					</div>
				</div>
			
				<?php
				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
			
			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		
</div>
</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php

get_footer();
